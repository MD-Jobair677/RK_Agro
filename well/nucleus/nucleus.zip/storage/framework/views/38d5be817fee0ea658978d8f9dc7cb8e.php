
<?php $__env->startSection('master'); ?>
    <div class="row">
        <div class="col-xxl">
            <div class="card">
                <div class="card-body table-responsive text-nowrap fixed-min-height-table">
                    <a href="<?php echo e(route('admin.booking.create')); ?>" class="btn btn-sm btn-success">
                        <span class="tf-icons las la-plus-circle me-1"></span>
                        <?php echo app('translator')->get('Add New'); ?>
                    </a>
                    <table class="table table-hover">
                        <thead>
                            <tr>
                                <th class="text-center"><?php echo app('translator')->get('SI'); ?></th>
                                <th class="text-center"><?php echo app('translator')->get('Booking Number'); ?></th>
                                <th class="text-center"><?php echo app('translator')->get('Customer Name'); ?></th>
                                <th class="text-center"><?php echo app('translator')->get('Delivery Location'); ?></th>
                                <th class="text-center"><?php echo app('translator')->get('Price'); ?></th>
                                <th class="text-center"><?php echo app('translator')->get('Actions'); ?></th>
                            </tr>
                        </thead>
                        <tbody class="table-border-bottom-0">
                            <?php $__empty_1 = true; $__currentLoopData = $bookings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td class="text-center"><?php echo e($loop->iteration); ?></td>
                                    <td class="text-center"><?php echo e($item->booking_number); ?></td>
                                    <td class="text-center"><?php echo e($item->customer->fullname); ?></td>
                                    <td class="text-center"><?php echo e($item->delivery_location->district_city); ?>/
                                        <?php if(strlen(__($item->delivery_location->area)) > 20): ?>
                                            <?php echo e(substr(__($item->delivery_location->area), 0, 35) . '...'); ?>

                                        <?php else: ?>
                                            <?php echo e(__($item->delivery_location->area)); ?>

                                        <?php endif; ?>
                                    <td class="text-center">
                                        <?php echo e(showAmount($item->bookingNumberGroupPrices($item->booking_number))); ?></td>
                                    <?php if($item->status == 1): ?>
                                        <td class="text-center">
                                            <div class="btn-group">
                                                <button class="btn btn-sm btn-label-primary dropdown-toggle" type="button"
                                                    data-bs-toggle="dropdown"
                                                    aria-expanded="false"><?php echo app('translator')->get('Action'); ?></button>
                                                <ul class="dropdown-menu">
                                                    <li>
                                                        <a class="dropdown-item"
                                                            href="<?php echo e(route('admin.booking.edit', $item->id)); ?>"
                                                            class="btn btn-sm btn-warning">
                                                            <span class="tf-icons las la-pen me-1"></span>
                                                            <?php echo app('translator')->get('Edit'); ?>
                                                        </a>
                                                    </li>
                                                    <li>
                                                        <a class="dropdown-item"
                                                            href="<?php echo e(route('admin.booking.view', $item->id)); ?>"
                                                            class="btn btn-sm btn-info"><span
                                                                class="tf-icons las la-eye me-1"></span>
                                                            <?php echo app('translator')->get('View'); ?>
                                                        </a>
                                                    </li>
                                                    <li>
                                                        <a class="dropdown-item"
                                                            href="<?php echo e(route('admin.booking.payment.list', $item->id)); ?>"
                                                            class="btn btn-sm btn-info">
                                                            <span class="tf-icons las la-money-bill-wave me-1"></span>
                                                            <?php echo app('translator')->get('Payment'); ?>
                                                        </a>
                                                    </li>
                                                    <li>
                                                        <a href="javascript:void(0)" class="dropdown-item delete"
                                                            data-id="<?php echo e($item->id); ?>">
                                                            <span class="las la-trash fs-6 link-danger"></span>
                                                            <?php echo app('translator')->get('Delete'); ?>
                                                        </a>
                                                    </li>


                                                    <div>


                                                        <form id="delete-form-<?php echo e($item->id); ?>"
                                                            action="<?php echo e(route('admin.booking.delete.booking', $item->id)); ?>"
                                                            method="POST" style="display:none;">
                                                            <?php echo csrf_field(); ?>
                                                            <?php echo method_field('DELETE'); ?>
                                                        </form>
                                                    </div>





                                                    <?php if($item->sale_price < $item->total_payment_amount): ?>
                                                        <li>
                                                            <a class="dropdown-item"
                                                                href="<?php echo e(route('admin.booking.refund.payment', $item->id)); ?>"
                                                                class="btn btn-sm btn-info">
                                                                <span class="tf-icons las la-money-bill-wave me-1"></span>
                                                                <?php echo app('translator')->get('Refund'); ?>
                                                            </a>
                                                        </li>
                                                    <?php endif; ?>
                                                    <?php if($item->sale_price <= $item->total_payment_amount): ?>
                                                        <li>
                                                            <a class="dropdown-item"
                                                                href="<?php echo e(route('admin.booking.delivery.print', $item->id)); ?>"
                                                                class="btn btn-sm btn-warning">
                                                                <span class="tf-icons las la-print me-1"></span>
                                                                <?php echo app('translator')->get('Print'); ?>
                                                            </a>
                                                        </li>
                                                    <?php endif; ?>
                                                </ul>
                                            </div>
                                        </td>
                                    <?php elseif($item->status == 3): ?>
                                        <td class="text-center">
                                            <a href="<?php echo e(route('admin.booking.cattles.delivery', $item->id)); ?>"
                                                class="btn btn-sm btn-info">
                                                <span class="tf-icons las la-truck me-1"></span>
                                                <?php echo app('translator')->get('Delivery'); ?>
                                            </a>
                                        </td>
                                    <?php else: ?>
                                        <td class="text-center">
                                            <a href="#" class="btn btn-sm btn-success">
                                                <?php echo app('translator')->get('Delivered'); ?>
                                            </a>
                                        </td>
                                    <?php endif; ?>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="100%" class="text-center"><?php echo e(__($emptyMessage)); ?></td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>

                <?php if($bookings->hasPages()): ?>
                    <div class="card-footer pagination justify-content-center">
                        <?php echo e(paginateLinks($bookings)); ?>

                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
    <?php if (isset($component)) { $__componentOriginal951fd3b0438967d6de05c34ae029981f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal951fd3b0438967d6de05c34ae029981f = $attributes; } ?>
<?php $component = App\View\Components\DecisionModal::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('decisionModal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\DecisionModal::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal951fd3b0438967d6de05c34ae029981f)): ?>
<?php $attributes = $__attributesOriginal951fd3b0438967d6de05c34ae029981f; ?>
<?php unset($__attributesOriginal951fd3b0438967d6de05c34ae029981f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal951fd3b0438967d6de05c34ae029981f)): ?>
<?php $component = $__componentOriginal951fd3b0438967d6de05c34ae029981f; ?>
<?php unset($__componentOriginal951fd3b0438967d6de05c34ae029981f); ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('breadcrumb'); ?>
    <?php if (isset($component)) { $__componentOriginal544536d57896589479704f53a6577b7c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal544536d57896589479704f53a6577b7c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.searchForm','data' => ['placeholder' => 'Search by number or customer name...','dateSearch' => 'no']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('searchForm'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['placeholder' => 'Search by number or customer name...','dateSearch' => 'no']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal544536d57896589479704f53a6577b7c)): ?>
<?php $attributes = $__attributesOriginal544536d57896589479704f53a6577b7c; ?>
<?php unset($__attributesOriginal544536d57896589479704f53a6577b7c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal544536d57896589479704f53a6577b7c)): ?>
<?php $component = $__componentOriginal544536d57896589479704f53a6577b7c; ?>
<?php unset($__componentOriginal544536d57896589479704f53a6577b7c); ?>
<?php endif; ?>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('page-script'); ?>
    <script>
        $(document).on('click', '.delete', function(e) {
            e.preventDefault();

            let id = $(this).data('id');

            Swal.fire({
                title: "Are you sure?",
                text: "You won't be able to revert this!",
                icon: "warning",
                showCancelButton: true,
                confirmButtonColor: "#3085d6",
                cancelButtonColor: "#d33",
                confirmButtonText: "Yes, delete it!"
            }).then((result) => {
                if (result.isConfirmed) {
                    document.getElementById('delete-form-' + id).submit();
                }
            });
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\NexERP\NexERP\well\nucleus\resources\views/admin/booking/index.blade.php ENDPATH**/ ?>