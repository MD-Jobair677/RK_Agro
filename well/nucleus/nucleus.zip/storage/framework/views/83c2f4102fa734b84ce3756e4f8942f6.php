

<?php $__env->startSection('content'); ?>
    <div class="layout-wrapper layout-content-navbar">
        <div class="layout-container">
            <?php echo $__env->make('admin.partials.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php echo $__env->make('admin.partials.topbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            <div class="layout-page">
                <div class="content-wrapper">
                    <div class="container-fluid flex-grow-1 container-p-y">
                        <div class="row">
                            <div class="col-xxl">
                                <div class="card mb-4">
                                    <div class="card-header d-flex flex-wrap gap-3 justify-content-between align-items-center">
                                        <h5 class="mb-0"><?php echo e(__($pageTitle)); ?></h5>
                                        <div class="d-flex flex-wrap justify-content-md-end gap-2 align-items-center">
                                            <?php echo $__env->yieldPushContent('breadcrumb'); ?>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <?php echo $__env->yieldContent('master'); ?>
                    </div>

                </div>
            </div>
        </div>

        <div class="layout-overlay layout-menu-toggle"></div>
        <div class="drag-target"></div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('page-script-lib'); ?>
    <script src="<?php echo e(asset('assets/admin/js/page/menu.js')); ?>"></script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\NexERP\NexERP\well\nucleus\resources\views/admin/layouts/master.blade.php ENDPATH**/ ?>