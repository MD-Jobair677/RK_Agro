<nav class="layout-navbar container-fluid navbar navbar-expand-xl navbar-detached align-items-center bg-navbar-theme" id="layout-navbar">
    <div class="layout-menu-toggle navbar-nav align-items-xl-center me-3 me-xl-0 d-xl-none">
        <a class="nav-item nav-link px-0 me-xl-4" href="javascript:void(0)">
            <i class="fas fa-bars"></i>
        </a>
    </div>

    <div class="navbar-nav-right d-flex align-items-center" id="navbar-collapse">
        <div class="navbar-nav align-items-center">
            <div id="searchBoxLg">
                <div class="nav-item d-flex align-items-center navbar-search">
                    <i class="las la-search fs-4 lh-0"></i>
                    <input type="text" class="form-control border-0 shadow-none w-100 navbar-search-field" id="searchInput" placeholder="Search..." autocomplete="off">
                    <ul class="search-list d-none"></ul>
                </div>
            </div>
        </div>

        <ul class="navbar-nav flex-row align-items-center ms-auto">
            <!-- Visit Website  -->
            <li class="nav-item dropdown-shortcuts navbar-dropdown dropdown me-2 me-xl-0">
                <a class="nav-link text-primary" href="<?php echo e(route('home')); ?>" target="_blank" title="<?php echo app('translator')->get('Visit Website'); ?>">
                    <i class="fas fa-globe"></i>
                </a>
            </li>
            <!-- Visit Website  -->

         
            <!-- Notification -->
            <li class="nav-item dropdown-notifications navbar-dropdown dropdown me-3 me-xl-1">
                <a class="nav-link dropdown-toggle hide-arrow" href="javascript:void(0);" data-bs-toggle="dropdown" data-bs-auto-close="outside" aria-expanded="false">
                    <i class="fas fa-bell"></i>
                    <span class="badge bg-danger badge-notifications"><?php echo e($adminNotificationCount); ?></span>
                </a>
                <ul class="dropdown-menu dropdown-menu-end py-0">
                    <li class="dropdown-menu-header border-bottom">
                        <div class="dropdown-header d-flex align-items-center py-3">
                            <h5 class="text-body mb-0 me-auto"><?php echo app('translator')->get('Notification'); ?></h5>
                            <a href="<?php echo e(route('admin.system.notification.read.all')); ?>" class="dropdown-notifications-all text-body" title="<?php echo app('translator')->get('Mark all as read'); ?>">
                                <i class="las la-envelope-open-text fs-4"></i>
                            </a>
                        </div>
                    </li>
                    <li class="dropdown-notifications-list scrollable-container">
                        <ul class="list-group list-group-flush">
                            <?php $__empty_1 = true; $__currentLoopData = $adminNotifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <li class="list-group-item list-group-item-action dropdown-notifications-item">
                                    <div class="d-flex">
                                        <a href="<?php echo e(route('admin.system.notification.read', $notification->id)); ?>" class="flex-grow-1">
                                            <h6 class="mb-1"><?php echo e(__($notification->title)); ?></h6>
                                            <small class="text-muted"><?php echo e($notification->created_at->diffForHumans()); ?></small>
                                        </a>
                                        <div class="flex-shrink-0 dropdown-notifications-actions">
                                            <div class="dropdown-notifications-read"><span class="badge badge-dot"></span></div>
                                        </div>
                                    </div>
                                </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <li class="list-group-item list-group-item-action dropdown-notifications-item">
                                    <div class="d-flex">
                                        <div class="flex-grow-1">
                                            <b><?php echo app('translator')->get('No notifications left to read'); ?></b>
                                        </div>
                                    </div>
                                </li>
                            <?php endif; ?>
                        </ul>
                    </li>
                    <li class="dropdown-menu-footer border-top p-3">
                        <a href="<?php echo e(route('admin.system.notification.all')); ?>" class="btn btn-primary w-100"><?php echo app('translator')->get('View all notifications'); ?></a>
                    </li>
                </ul>
            </li>
            <!--/ Notification -->

            <!-- Admin -->
            <li class="nav-item navbar-dropdown dropdown-user dropdown">
                <a class="nav-link dropdown-toggle hide-arrow" href="javascript:void(0);" data-bs-toggle="dropdown">
                    <div class="avatar avatar-online">
                        <img src="<?php echo e(getImage(getFilePath('adminProfile') . '/' . auth('admin')->user()->image, getFileSize('adminProfile'))); ?>" alt class="w-px-40 h-auto rounded-circle">
                    </div>
                </a>
                <ul class="dropdown-menu dropdown-menu-end">
                    <li>
                        <a class="dropdown-item d-flex" href="<?php echo e(route('admin.profile')); ?>">
                            <i class="las la-user-tie fs-4 me-2"></i>
                            <span class="align-middle"><?php echo app('translator')->get('Profile'); ?></span>
                        </a>
                    </li>
                    <li>
                        <a class="dropdown-item d-flex" href="<?php echo e(route('admin.password')); ?>">
                            <i class="las la-key fs-4 me-2"></i>
                            <span class="align-middle"><?php echo app('translator')->get('Password'); ?></span>
                        </a>
                    </li>
                    <li>
                        <a class="dropdown-item d-flex" href="<?php echo e(route('admin.basic.setting')); ?>">
                            <i class="las la-cog fs-4 me-2"></i>
                            <span class="align-middle"><?php echo app('translator')->get('Settings'); ?></span>
                        </a>
                    </li>
                    <li>
                        <div class="dropdown-divider"></div>
                    </li>
                    <li>
                        <a class="dropdown-item d-flex" href="<?php echo e(route('admin.logout')); ?>">
                            <i class="las la-power-off fs-4 me-2"></i>
                            <span class="align-middle"><?php echo app('translator')->get('Log Out'); ?></span>
                        </a>
                    </li>
                </ul>
            </li>
            <!--/ Admin -->
        </ul>
    </div>
</nav>
<?php /**PATH E:\NexERP\NexERP\well\nucleus\resources\views/admin/partials/topbar.blade.php ENDPATH**/ ?>