
<?php $__env->startSection('master'); ?>
    <div class="row">
        <div class="col-xxl">
            <div class="card">
                <div class="card-body table-responsive text-nowrap fixed-min-height-table">
                    <a href="<?php echo e(route('admin.cattle.create')); ?>" class="btn btn-sm btn-success">
                        <span class="tf-icons las la-plus-circle me-1"></span>
                        <?php echo app('translator')->get('Add New'); ?>
                    </a>
                    <table class="table table-hover">
                        <thead>
                            <tr>
                                <th class="text-center"><?php echo app('translator')->get('SI'); ?></th>
                                <th class="text-center"><?php echo app('translator')->get('Image'); ?></th>
                                <th class="text-center"><?php echo app('translator')->get('Tag Number'); ?></th>
                                <th class="text-center"><?php echo app('translator')->get('Cattle Name'); ?></th>
                                <th class="text-center"><?php echo app('translator')->get('Category Name'); ?></th>
                                <th class="text-center"><?php echo app('translator')->get('Asking Price'); ?></th>
                                <th class="text-center"><?php echo app('translator')->get('Weight'); ?></th>
                                <th class="text-center"><?php echo app('translator')->get('Status'); ?></th>
                                <th class="text-center"><?php echo app('translator')->get('Actions'); ?></th>
                            </tr>
                        </thead>
                        <tbody class="table-border-bottom-0">
                            <?php $__empty_1 = true; $__currentLoopData = $cattles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cattle): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td class="text-center"><?php echo e($loop->iteration); ?></td>
                                    <td class="text-center">
                                        <img class="rounded"
                                            src="<?php echo e(getImage(getFilePath('cattle') . '/' . optional($cattle->primaryImage)->image_path)); ?>"
                                            alt="admin-image" style="width:50px">
                                    </td>

                                    <td class="text-center"><?php echo e($cattle->tag_number); ?></td>
                                    <td class="text-center"><?php echo e($cattle->name); ?></td>
                                    <td class="text-center"><?php echo e($cattle->cattleCategory->name); ?></td>
                                    <td class="text-center"><?php echo e($cattle->asking_price); ?></td>
                                    <td class="text-center"><?php echo e($cattle->purchase_weight); ?></td>
                                    <td class="text-center"><?php echo $cattle->statusBadge ?></td>
                                    <?php if($cattle->status == 1 || $cattle->status == 2): ?>
                                    <td class="text-center">
                                        <div>
                                            <div class="btn-group">
                                                <button class="btn btn-sm btn-label-primary dropdown-toggle" type="button"
                                                    data-bs-toggle="dropdown"
                                                    aria-expanded="false"><?php echo app('translator')->get('Action'); ?></button>
                                                <ul class="dropdown-menu">
                                                    <li>
                                                        <a class="dropdown-item"
                                                            href="<?php echo e(route('admin.cattle.edit', $cattle->id)); ?>">
                                                            <span class="las la-pen fs-6 link-warning"></span>
                                                            <?php echo app('translator')->get('Edit Cattle'); ?>
                                                        </a>
                                                    </li>
                                                    <?php if($cattle->status == 1): ?>
                                                    <li>
                                                        <a class="dropdown-item"
                                                            href="<?php echo e(route('admin.cattle.edit_weight', $cattle->id)); ?>">
                                                            <span class="las la-pen fs-6 link-warning"></span>
                                                            <?php echo app('translator')->get('Edit Weight & Purchase'); ?>
                                                        </a>
                                                    </li>
                                                    <li>
                                                        <a class="dropdown-item"
                                                            href="<?php echo e(route('admin.cattle.detail', $cattle->id)); ?>">
                                                            <span class="tf-icons las la-info-circle me-1"></span>
                                                            <?php echo app('translator')->get('Details'); ?>
                                                        </a>
                                                    </li>
                                                    <?php endif; ?>
                                                </ul>
                                            </div>
                                        </div>
                                    </td>
                                    <?php endif; ?>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="100%" class="text-center"><?php echo e(__($emptyMessage)); ?></td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>

                <?php if($cattles->hasPages()): ?>
                    <div class="card-footer pagination justify-content-center">
                        <?php echo e(paginateLinks($cattles)); ?>

                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <div class="offcanvas offcanvas-end" data-bs-scroll="true" tabindex="-1" id="offcanvasBoth"
        aria-labelledby="offcanvasBothLabel">
        <div class="offcanvas-header">
            <h4 id="offcanvasBothLabel" class="offcanvas-title"><?php echo app('translator')->get('Role Details'); ?></h4>
        </div>
        <div class="offcanvas-body my-auto mx-0 flex-grow-0">
            <div class="mb-4">
                <h5><?php echo app('translator')->get('Role Description'); ?></h5>
                <div class="border rounded p-3">
                    <p class="userMessage mb-0"></p>
                </div>
            </div>
            <button type="button" class="btn btn-secondary d-grid w-100 mt-4" data-bs-dismiss="offcanvas">
                <?php echo app('translator')->get('Close'); ?>
            </button>
        </div>
    </div>

    <?php if (isset($component)) { $__componentOriginal951fd3b0438967d6de05c34ae029981f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal951fd3b0438967d6de05c34ae029981f = $attributes; } ?>
<?php $component = App\View\Components\DecisionModal::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('decisionModal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\DecisionModal::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal951fd3b0438967d6de05c34ae029981f)): ?>
<?php $attributes = $__attributesOriginal951fd3b0438967d6de05c34ae029981f; ?>
<?php unset($__attributesOriginal951fd3b0438967d6de05c34ae029981f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal951fd3b0438967d6de05c34ae029981f)): ?>
<?php $component = $__componentOriginal951fd3b0438967d6de05c34ae029981f; ?>
<?php unset($__componentOriginal951fd3b0438967d6de05c34ae029981f); ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('breadcrumb'); ?>
    <?php if (isset($component)) { $__componentOriginal544536d57896589479704f53a6577b7c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal544536d57896589479704f53a6577b7c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.searchForm','data' => ['placeholder' => 'Search Cattle by Tag Number...','dateSearch' => 'no']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('searchForm'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['placeholder' => 'Search Cattle by Tag Number...','dateSearch' => 'no']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal544536d57896589479704f53a6577b7c)): ?>
<?php $attributes = $__attributesOriginal544536d57896589479704f53a6577b7c; ?>
<?php unset($__attributesOriginal544536d57896589479704f53a6577b7c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal544536d57896589479704f53a6577b7c)): ?>
<?php $component = $__componentOriginal544536d57896589479704f53a6577b7c; ?>
<?php unset($__componentOriginal544536d57896589479704f53a6577b7c); ?>
<?php endif; ?>
<?php $__env->stopPush(); ?>



<?php $__env->startPush('page-script'); ?>
    <script>
        (function($) {
            "use strict";

            $('.detailBtn').on('click', function() {
                let message = $(this).data('message');
                $('.userMessage').text(message);
            });
        })(jQuery);
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\NexERP\NexERP\well\nucleus\resources\views/admin/cattle/index.blade.php ENDPATH**/ ?>