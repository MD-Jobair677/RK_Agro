
<?php $__env->startSection('master'); ?>
    <div class="row">
        <div class="col-xxl">
            <div class="card">
                <div class="card-body table-responsive text-nowrap fixed-min-height-table">
                    <table class="table table-hover">
                        <thead>
                            <tr>
                                <th class="text-center"><?php echo app('translator')->get('SI'); ?></th>
                                <th class="text-center"><?php echo app('translator')->get('Image'); ?></th>
                                <th class="text-center"><?php echo app('translator')->get('Name'); ?></th>
                                <th class="text-center"><?php echo app('translator')->get('UserName'); ?></th>
                                <th class="text-center"><?php echo app('translator')->get('Email'); ?></th>
                                <th class="text-center"><?php echo app('translator')->get('Created-At'); ?></th>
                                <th class="text-center"><?php echo app('translator')->get('Actions'); ?></th>
                            </tr>
                        </thead>
                        <tbody class="table-border-bottom-0">
                            <?php $__empty_1 = true; $__currentLoopData = $admins; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $admin): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr class="text-center">
                                    <td><?php echo e($loop->iteration); ?></td>
                                    <td>
                                        <img class="w-50"
                                            src="<?php echo e(getImage(getFilePath('adminProfile') . '/' . $admin->image)); ?>"
                                            alt="admin-image">
                                    </td>
                                    <td class="text-center"><?php echo e($admin->name); ?></td>
                                    <td class="text-center"><?php echo e($admin->username); ?></td>
                                    <td class="text-center"><?php echo e($admin->email); ?></td>
                                    <td class="text-center"><?php echo e(showDateTime($admin->created_at,'d-m-y, h:i A')); ?></td>
                                    <td class="text-center">
                                        <div>
                                            <button type="button" class="btn btn-sm btn-label-info detailBtn"
                                                data-bs-toggle      = "offcanvas" data-bs-target      = "#offcanvasBoth"
                                                aria-controls       = "offcanvasBoth"
                                                data-message        = "<?php echo e($admin->roles->pluck('name')->implode(', ')); ?>">
                                                <span class="tf-icons las la-info-circle me-1"></span> <?php echo app('translator')->get('View Roles'); ?>
                                            </button>
                                            <a class="btn btn-sm btn-primary btn-label-info"
                                                href="<?php echo e(route('admin.role.set', $admin->id)); ?>">
                                                <span class="tf-icons las la-user-tag me-1"></span> <?php echo app('translator')->get('Set Roles'); ?>
                                            </a>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="100%" class="text-center"><?php echo e(__($emptyMessage)); ?></td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>

                <?php if($admins->hasPages()): ?>
                    <div class="card-footer pagination justify-content-center">
                        <?php echo e(paginateLinks($admins)); ?>

                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <div class="offcanvas offcanvas-end" data-bs-scroll="true" tabindex="-1" id="offcanvasBoth"
        aria-labelledby="offcanvasBothLabel">
        <div class="offcanvas-header">
            <h4 id="offcanvasBothLabel" class="offcanvas-title"><?php echo app('translator')->get('Role Details'); ?></h4>
        </div>
        <div class="offcanvas-body my-auto mx-0 flex-grow-0">
            <div class="mb-4">
                <h5><?php echo app('translator')->get('Roles'); ?></h5>
                <div class="border rounded p-3">
                    <p class="userMessage mb-0"></p>
                </div>
            </div>
            <button type="button" class="btn btn-secondary d-grid w-100 mt-4" data-bs-dismiss="offcanvas">
                <?php echo app('translator')->get('Close'); ?>
            </button>
        </div>
    </div>

    <?php if (isset($component)) { $__componentOriginal951fd3b0438967d6de05c34ae029981f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal951fd3b0438967d6de05c34ae029981f = $attributes; } ?>
<?php $component = App\View\Components\DecisionModal::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('decisionModal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\DecisionModal::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal951fd3b0438967d6de05c34ae029981f)): ?>
<?php $attributes = $__attributesOriginal951fd3b0438967d6de05c34ae029981f; ?>
<?php unset($__attributesOriginal951fd3b0438967d6de05c34ae029981f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal951fd3b0438967d6de05c34ae029981f)): ?>
<?php $component = $__componentOriginal951fd3b0438967d6de05c34ae029981f; ?>
<?php unset($__componentOriginal951fd3b0438967d6de05c34ae029981f); ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('breadcrumb'); ?>
    <?php if (isset($component)) { $__componentOriginal544536d57896589479704f53a6577b7c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal544536d57896589479704f53a6577b7c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.searchForm','data' => ['placeholder' => 'Search admin...','dateSearch' => 'no']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('searchForm'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['placeholder' => 'Search admin...','dateSearch' => 'no']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal544536d57896589479704f53a6577b7c)): ?>
<?php $attributes = $__attributesOriginal544536d57896589479704f53a6577b7c; ?>
<?php unset($__attributesOriginal544536d57896589479704f53a6577b7c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal544536d57896589479704f53a6577b7c)): ?>
<?php $component = $__componentOriginal544536d57896589479704f53a6577b7c; ?>
<?php unset($__componentOriginal544536d57896589479704f53a6577b7c); ?>
<?php endif; ?>
<?php $__env->stopPush(); ?>



<?php $__env->startPush('page-script'); ?>
    <script>
        (function($) {
            "use strict";

            $('.detailBtn').on('click', function() {
                let message = $(this).data('message');
                $('.userMessage').text(message);
            });
        })(jQuery);
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\NexERP\NexERP\well\nucleus\resources\views/admin/admin-role/index.blade.php ENDPATH**/ ?>