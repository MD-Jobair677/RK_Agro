

<?php $__env->startSection('master'); ?>
   <!-- users -->
    <div class="row">
        <div class="col-12">
            <div class="card mb-4">
                <div class="card-widget-separator-wrapper">
                    <div class="card-body card-widget-separator">
                        <div class="row gy-4 gy-sm-1">
                            <a href="<?php echo e(route('admin.user.index')); ?>" class="col-sm-6 col-lg-3">
                                <div class="d-flex justify-content-between align-items-start card-widget-1 border-end pb-3 pb-sm-0">
                                    <div>
                                        <h3 class="mb-1"><?php echo e($widget['totalUsersCount']); ?></h3>
                                        <p class="mb-0"><?php echo app('translator')->get('Total Users'); ?></p>
                                    </div>
                                    <span class="badge bg-label-primary rounded p-2 me-sm-4">
                                        <i class="las la-users fs-3"></i>
                                    </span>
                                </div>
                                <hr class="d-none d-sm-block d-lg-none me-4">
                            </a>
                            <a href="<?php echo e(route('admin.user.active')); ?>" class="col-sm-6 col-lg-3">
                                <div class="d-flex justify-content-between align-items-start card-widget-2 border-end pb-3 pb-sm-0">
                                    <div>
                                        <h3 class="mb-1"><?php echo e($widget['activeUsersCount']); ?></h3>
                                        <p class="mb-0"><?php echo app('translator')->get('Active Users'); ?></p>
                                    </div>
                                    <span class="badge bg-label-info rounded p-2 me-lg-4">
                                        <i class="la las la-user-check fs-3"></i>
                                    </span>
                                </div>
                                <hr class="d-none d-sm-block d-lg-none">
                            </a>
                            <a href="<?php echo e(route('admin.user.email.unconfirmed')); ?>" class="col-sm-6 col-lg-3">
                                <div class="d-flex justify-content-between align-items-start border-end pb-3 pb-sm-0 card-widget-3">
                                    <div>
                                        <h3 class="mb-1"><?php echo e($widget['unconfirmedEmailUsersCount']); ?></h3>
                                        <p class="mb-0"><?php echo app('translator')->get('Unconfirmed Email'); ?></p>
                                    </div>
                                    <span class="badge bg-label-warning rounded p-2 me-sm-4">
                                        <i class="las la-envelope-open-text fs-3"></i>
                                    </span>
                                </div>
                            </a>
                            <a href="<?php echo e(route('admin.user.mobile.unconfirmed')); ?>" class="col-sm-6 col-lg-3">
                                <div class="d-flex justify-content-between align-items-start">
                                    <div>
                                        <h3 class="mb-1"><?php echo e($widget['unconfirmedMobileUsersCount']); ?></h3>
                                        <p class="mb-0"><?php echo app('translator')->get('Unconfirmed Mobile'); ?></p>
                                    </div>
                                    <span class="badge bg-label-danger rounded p-2">
                                        <i class="las la-phone-volume fs-3"></i>
                                    </span>
                                </div>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
  <!-- deposit -->
    
 <!-- withdrawal -->
    
<?php $__env->stopSection(); ?>




<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\NexERP\NexERP\well\nucleus\resources\views/admin/page/dashboard.blade.php ENDPATH**/ ?>