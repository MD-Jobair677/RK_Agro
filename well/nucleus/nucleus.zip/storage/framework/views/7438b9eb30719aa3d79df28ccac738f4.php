
<?php $__env->startSection('master'); ?>
    <div class="row">
        <div class="col-xxl">
            <div class="card">
                <div class="card-body table-responsive text-nowrap fixed-min-height-table">
                    <a href="<?php echo e(route('admin.inventory.stock.create', $warehouse->name)); ?>" class="btn btn-sm btn-success">
                        <span class="tf-icons las la-plus-circle me-1"></span>
                        <?php echo app('translator')->get('Add New'); ?>
                    </a>
                    <a href="<?php echo e(route('admin.inventory.wh.stock.history', $warehouse->name)); ?>" class="btn btn-sm btn-warning">
                        <span class="fa-solid fa-ellipsis-vertical me-1"></span>
                        <?php echo app('translator')->get('Stock History'); ?>
                    </a>
                    <table class="table table-hover">
                        <thead>
                            <tr>
                                <th class="text-center"><?php echo app('translator')->get('SI'); ?></th>
                                <th class="text-center"><?php echo app('translator')->get('Item'); ?></th>
                                
                                
                                <th class="text-center"><?php echo app('translator')->get('Quantity'); ?></th>
                                <th class="text-center"><?php echo app('translator')->get('Last Purchase Date'); ?></th>
                                <th class="text-center"><?php echo app('translator')->get('Last Stock In'); ?></th>
                                <th class="text-center"><?php echo app('translator')->get('Last Issue Date'); ?></th>
                                <th class="text-center"><?php echo app('translator')->get('Last Stock Out'); ?></th>
                                <th class="text-center"><?php echo app('translator')->get('Unite Of Measurement'); ?></th>
                                
                                <th class="text-center"><?php echo app('translator')->get('Actions'); ?></th>
                            </tr>
                        </thead>
                        <tbody class="table-border-bottom-0">
                            <?php $__empty_1 = true; $__currentLoopData = $invStocks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td class="text-center"><?php echo e($loop->iteration); ?></td>
                                    <td class="text-center"><?php echo e($item->item->name); ?></td>
                                    
                                    
                                    <td class="text-center"><?php echo e($item->quantity); ?></td>
                                    <td class="text-center"><?php echo e($item->purchase_date); ?></td>
                                    <td class="text-center"><?php echo e($item->quantity_in); ?></td>
                                    <td class="text-center"><?php echo e($item->last_issue_date); ?></td>
                                    <td class="text-center"><?php echo e($item->quantity_out); ?></td>
                                    <td class="text-center"><?php echo e($item->unit_of_measurement); ?></td>
                                    
                                    <td class="text-center">
                                        <div>
                                            
                                            <a href="<?php echo e(route('admin.inventory.stock.edit', [$warehouse->name, $item->item->id])); ?>"
                                                class="btn btn-sm btn-success">
                                                <span>+</span>
                                                <?php echo app('translator')->get('Increase'); ?>
                                            </a>
                                            <a href="<?php echo e(route('admin.inventory.issue.create', [$warehouse->name, $item->item->id])); ?>"
                                                class="btn btn-sm btn-danger">
                                                <?php echo app('translator')->get('-Decrease'); ?>
                                            </a>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="100%" class="text-center"><?php echo e(__($emptyMessage)); ?></td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>

                <?php if($invStocks->hasPages()): ?>
                    <div class="card-footer pagination justify-content-center">
                        <?php echo e(paginateLinks($invStocks)); ?>

                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <div class="offcanvas offcanvas-end" data-bs-scroll="true" tabindex="-1" id="offcanvasBoth"
        aria-labelledby="offcanvasBothLabel">

        <div class="offcanvas-body my-auto mx-0 flex-grow-0">
            <div class="mb-4">

                <div class="basicData"></div>
            </div>
            <button type="button" class="btn btn-secondary d-grid w-100 mt-4" data-bs-dismiss="offcanvas">
                <?php echo app('translator')->get('Close'); ?>
            </button>
        </div>
    </div>



    <?php if (isset($component)) { $__componentOriginal951fd3b0438967d6de05c34ae029981f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal951fd3b0438967d6de05c34ae029981f = $attributes; } ?>
<?php $component = App\View\Components\DecisionModal::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('decisionModal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\DecisionModal::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal951fd3b0438967d6de05c34ae029981f)): ?>
<?php $attributes = $__attributesOriginal951fd3b0438967d6de05c34ae029981f; ?>
<?php unset($__attributesOriginal951fd3b0438967d6de05c34ae029981f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal951fd3b0438967d6de05c34ae029981f)): ?>
<?php $component = $__componentOriginal951fd3b0438967d6de05c34ae029981f; ?>
<?php unset($__componentOriginal951fd3b0438967d6de05c34ae029981f); ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('breadcrumb'); ?>
    <?php if (isset($component)) { $__componentOriginal544536d57896589479704f53a6577b7c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal544536d57896589479704f53a6577b7c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.searchForm','data' => ['placeholder' => 'Search Item name...','dateSearch' => 'no']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('searchForm'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['placeholder' => 'Search Item name...','dateSearch' => 'no']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal544536d57896589479704f53a6577b7c)): ?>
<?php $attributes = $__attributesOriginal544536d57896589479704f53a6577b7c; ?>
<?php unset($__attributesOriginal544536d57896589479704f53a6577b7c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal544536d57896589479704f53a6577b7c)): ?>
<?php $component = $__componentOriginal544536d57896589479704f53a6577b7c; ?>
<?php unset($__componentOriginal544536d57896589479704f53a6577b7c); ?>
<?php endif; ?>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('page-script'); ?>
    <script>
        $('.detailBtn').on('click', function() {
            let invStockData = $(this).data('inv_stock');
            console.log(invStockData);

            let basicHtml = `<div class="mb-4">
                                <h5><?php echo app('translator')->get('Customer Information'); ?></h5>
                                <ul class="list-group">
                                    <li class="list-group-item d-flex justify-content-between align-items-center">
                                        <b><?php echo app('translator')->get('Item'); ?></b>
                                        <span>${invStockData.item.name}</span>
                                    </li>
                                    <li class="list-group-item d-flex justify-content-between align-items-center">
                                        <b><?php echo app('translator')->get('Warehouse'); ?></b>
                                        <span>${invStockData.warehouse.name}</span>
                                    </li>
                                    <li class="list-group-item d-flex justify-content-between align-items-center">
                                        <b><?php echo app('translator')->get('Supplier'); ?></b>
                                        <span>${invStockData.supplier.name}</span>
                                    </li>
                                    <li class="list-group-item d-flex justify-content-between align-items-center">
                                        <b><?php echo app('translator')->get('Purchase Date'); ?></b>
                                        <span>${invStockData.purchase_date}</span>
                                    </li>
                                    <li class="list-group-item d-flex justify-content-between align-items-center">
                                        <b><?php echo app('translator')->get('Quantity In'); ?></b>
                                        <span>${invStockData.quantity_in}</span>
                                    </li>
                                    <li class="list-group-item d-flex justify-content-between align-items-center">
                                        <b><?php echo app('translator')->get('Unit Of Measurement'); ?></b>
                                        <span>${invStockData.unit_of_measurement}</span>
                                    </li>
                                    <li class="list-group-item d-flex justify-content-between align-items-center">
                                        <b><?php echo app('translator')->get('Rate Per Unit'); ?></b>
                                        <span>${invStockData.rate_per_unit}</span>
                                    </li>
                                    <li class="list-group-item d-flex justify-content-between align-items-center">
                                        <b><?php echo app('translator')->get('Total Amount'); ?></b>
                                        <span>${invStockData.total_amount}</span>
                                    </li>
                                    <li class="list-group-item d-flex justify-content-between align-items-center">
                                        <b><?php echo app('translator')->get('Remark'); ?></b>
                                        <span>${invStockData.remark}</span>
                                    </li>
                                    <li class="list-group-item d-flex justify-content-between align-items-center">
                                        <b><?php echo app('translator')->get('Reference'); ?></b>
                                        <span>${invStockData.reference}</span>
                                    </li>`;
            basicHtml += `</ul>
                    </div>`;

            $('.basicData').html(basicHtml);

        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\NexERP\NexERP\well\nucleus\resources\views/admin/inventory_manage/wh_stk_index.blade.php ENDPATH**/ ?>