<?php
    $admin = auth('admin')->user();
?>

<aside id="layout-menu" class="layout-menu menu-vertical menu bg-menu-theme">
    <div class="app-brand demo">
        <a href="<?php echo e(route('admin.dashboard')); ?>" class="app-brand-link">
            <span class="app-brand-text demo menu-text fw-bolder ms-2 logo-big">
                <img src="<?php echo e(getImage(getFilePath('logoFavicon') . '/logo_dark.png')); ?>" alt="logo">
            </span>
            <span class="app-brand-text demo menu-text fw-bolder logo-small">
                <img src="<?php echo e(getImage(getFilePath('logoFavicon') . '/favicon.png')); ?>" alt="logo">
            </span>
        </a>

        <a href="javascript:void(0);" class="layout-menu-toggle menu-link text-large ms-auto">
            <i class="las la-chevron-left align-middle"></i>
        </a>
    </div>

    <div id="searchBoxSm"></div>
    <div class="menu-inner-shadow"></div>

    <ul class="menu-inner py-1">

        <li class="menu-item <?php echo e(sideMenuActive('admin.dashboard', 1)); ?>">
            <a href="<?php echo e(route('admin.dashboard')); ?>" class="menu-link">
                <i class="menu-icon tf-icons las la-tachometer-alt text-primary"></i>
                <div class="text-truncate"><?php echo app('translator')->get('Dashboard'); ?></div>
            </a>
        </li>
        <!-- manange users -->
        


        <?php if(Gate::forUser($admin)->check('has-permission', 'admin list')): ?>
            <li class="menu-header small">
                <span class="menu-header-text"><?php echo app('translator')->get('Admins'); ?></span>
            </li>

            <li class="menu-item <?php echo e(sideMenuActive('admin.admin*', 1)); ?>">
                <a href="<?php echo e(route('admin.admin.index')); ?>" class="menu-link">
                    <div class="text-truncate"><?php echo app('translator')->get('Admin List'); ?></div>
                </a>
            </li>
        <?php endif; ?>


        <?php if(Gate::forUser($admin)->check('has-permission', 'category list')): ?>
            
            <li class="menu-header small">
                <span class="menu-header-text"><?php echo app('translator')->get('Category'); ?></span>
            </li>

            <li class="menu-item <?php echo e(sideMenuActive('admin.category*', 1)); ?>">
                <a href="<?php echo e(route('admin.category.index')); ?>" class="menu-link">
                    <div class="text-truncate"><?php echo app('translator')->get('Category'); ?></div>
                </a>
            </li>
        <?php endif; ?>


        <?php if(Gate::forUser($admin)->check('has-permission', 'cattle category')): ?>
            <li class="menu-item <?php echo e(sideMenuActive('admin.cattle.category*', 1)); ?>">
                <a href="<?php echo e(route('admin.cattle.category.index')); ?>" class="menu-link">
                    <div class="text-truncate"><?php echo app('translator')->get('Cattle Category'); ?></div>
                </a>
            </li>
        <?php endif; ?>

        
        <?php if(Gate::forUser($admin)->check('has-permission', 'expenses list')): ?>
            <li class="menu-header small">
                <span class="menu-header-text"><?php echo app('translator')->get('Expense Manage'); ?></span>
            </li>

            <li class="menu-item <?php echo e(sideMenuActive('admin.account*', 3)); ?>">
                <a href="javascript:void(0);" class="menu-link menu-toggle">
                    <i class="menu-icon tf-icons las la-credit-card text-info"></i>
                    <div class="text-truncate"><?php echo app('translator')->get('Expenses'); ?></div>
                </a>
                <ul class="menu-sub">
                    
                    <li class="menu-item <?php echo e(sideMenuActive('admin.account.gen_expns.index*', 1)); ?>">
                        <a href="<?php echo e(route('admin.account.gen_expns.index', 'general')); ?>" class="menu-link">
                            <div class="text-truncate"><?php echo app('translator')->get('General'); ?></div>
                        </a>
                    </li>
                    <li class="menu-item <?php echo e(sideMenuActive('admin.account.gen_expns.index*', 1)); ?>">
                        <a href="<?php echo e(route('admin.account.gen_expns.index', 'food')); ?>" class="menu-link">
                            <div class="text-truncate"><?php echo app('translator')->get('Food'); ?></div>
                        </a>
                    </li>
                    <li class="menu-item <?php echo e(sideMenuActive('admin.account.gen_expns.index*', 1)); ?>">
                        <a href="<?php echo e(route('admin.account.gen_expns.index', 'medicine')); ?>" class="menu-link">
                            <div class="text-truncate"><?php echo app('translator')->get('Medicine'); ?></div>
                        </a>
                    </li>
                    <li class="menu-item <?php echo e(sideMenuActive('admin.account.gen_expns.index*', 1)); ?>">
                        <a href="<?php echo e(route('admin.account.gen_expns.index', 'cattle')); ?>" class="menu-link">
                            <div class="text-truncate"><?php echo app('translator')->get('Cattle Purchase'); ?></div>
                        </a>
                    </li>
                </ul>
            </li>
        <?php endif; ?>

        

        <?php if(Gate::forUser($admin)->check('has-permission', 'cattle list')): ?>
            <li class="menu-header small">
                <span class="menu-header-text"><?php echo app('translator')->get('Cattle Manage'); ?></span>
            </li>
        <?php endif; ?>

        <?php if(Gate::forUser($admin)->check('has-permission', 'cattle list')): ?>
            <li class="menu-item <?php echo e(sideMenuActive('admin.cattle*', 3)); ?>">
                <a href="javascript:void(0);" class="menu-link menu-toggle">
                    <i class="menu-icon tf-icons las la-credit-card text-info"></i>
                    <div class="text-truncate"><?php echo app('translator')->get('Cattles'); ?></div>
                </a>
                <ul class="menu-sub">
                    <li class="menu-item <?php echo e(sideMenuActive('admin.cattle.index*', 1)); ?>">
                        <a href="<?php echo e(route('admin.cattle.index')); ?>" class="menu-link">
                            <div class="text-truncate"><?php echo app('translator')->get('Cattle List'); ?></div>
                        </a>
                    </li>
                    <li class="menu-item <?php echo e(sideMenuActive('admin.booking.index*', 1)); ?>">
                        <a href="<?php echo e(route('admin.booking.index')); ?>" class="menu-link">
                            <div class="text-truncate"><?php echo app('translator')->get('Cattle bookings'); ?></div>
                        </a>
                    </li>
                </ul>
            </li>
        <?php endif; ?>
        
        <li class="menu-header small">
            <span class="menu-header-text"><?php echo app('translator')->get('Common System Manage'); ?></span>
        </li>

        <li class="menu-item <?php echo e(sideMenuActive('admin.common*', 3)); ?>">
            <a href="javascript:void(0);" class="menu-link menu-toggle">
                <i class="menu-icon tf-icons las la-credit-card text-info"></i>
                <div class="text-truncate"><?php echo app('translator')->get('Common Setup'); ?></div>
            </a>
            <ul class="menu-sub">
                
                <li class="menu-item <?php echo e(sideMenuActive('admin.common.item.index*', 1)); ?>">
                    <a href="<?php echo e(route('admin.common.item.index')); ?>" class="menu-link">
                        <div class="text-truncate"><?php echo app('translator')->get('Item List'); ?></div>
                    </a>
                </li>
                <li class="menu-item <?php echo e(sideMenuActive('admin.supplier.index*', 1)); ?>">
                    <a href="<?php echo e(route('admin.supplier.index')); ?>" class="menu-link">
                        <div class="text-truncate"><?php echo app('translator')->get('Supplier List'); ?></div>
                    </a>
                </li>
                <li class="menu-item <?php echo e(sideMenuActive('admin.customer.index*', 1)); ?>">
                    <a href="<?php echo e(route('admin.customer.index')); ?>" class="menu-link">
                        <div class="text-truncate"><?php echo app('translator')->get('Customer List'); ?></div>
                    </a>
                </li>
            </ul>
        </li>

        
        <li class="menu-header small">
            <span class="menu-header-text"><?php echo app('translator')->get('Inventory Manage'); ?></span>
        </li>

            <li class="menu-item <?php echo e(sideMenuActive('admin.inventory*', 3)); ?>">
                <a href="javascript:void(0);" class="menu-link menu-toggle">
                    <i class="menu-icon tf-icons las la-credit-card text-info"></i>
                    <div class="text-truncate"><?php echo app('translator')->get('Inventory'); ?></div>
                </a>
                <ul class="menu-sub">
                    <li class="menu-item <?php echo e(sideMenuActive('admin.inventory.stock.index.*', 1)); ?>">
                        <a href="<?php echo e(route('admin.inventory.stock.index', 'food store')); ?>" class="menu-link">
                            <div class="text-truncate"><?php echo app('translator')->get('Food Store'); ?></div>
                        </a>
                    </li>
                    <li class="menu-item <?php echo e(sideMenuActive('admin.inventory.stock.index.*', 1)); ?>">
                        <a href="<?php echo e(route('admin.inventory.stock.index', 'medicine store')); ?>" class="menu-link">
                            <div class="text-truncate"><?php echo app('translator')->get('Medicine Store'); ?></div>
                        </a>
                    </li>
                    <li class="menu-item <?php echo e(sideMenuActive('admin.inventory.stock.index.*', 1)); ?>">
                        <a href="<?php echo e(route('admin.inventory.stock.index', 'general store')); ?>" class="menu-link">
                            <div class="text-truncate"><?php echo app('translator')->get('General Store'); ?></div>
                        </a>
                    </li>
                    <li class="menu-item <?php echo e(sideMenuActive('admin.inventory.issue*', 1)); ?>">
                        <a href="<?php echo e(route('admin.inventory.issue.index')); ?>" class="menu-link">
                            <div class="text-truncate"><?php echo app('translator')->get('Inventory Issues History'); ?></div>
                        </a>
                    </li>
                </ul>
            </li>

        <?php if(Gate::forUser($admin)->check('has-permission', 'delivery list')): ?>
            <li class="menu-header small">
                <span class="menu-header-text"><?php echo app('translator')->get('Delivery'); ?></span>
            </li>
            <li class="menu-item sidebar-menu-item">
                <a href="<?php echo e(route('admin.booking.delivery.index')); ?>" class="menu-link">
                    <i class="menu-icon tf-icons las la-eraser text-indigo"></i>
                    <div class="text-truncate"><?php echo app('translator')->get('Delivery List'); ?></div>
                </a>
            </li>
        <?php endif; ?>

        
        <?php if(Gate::forUser($admin)->check('has-permission', 'role permission list')): ?>
            <li class="menu-header small">
                <span class="menu-header-text"><?php echo app('translator')->get('Role & Permission'); ?></span>
            </li>

            <li class="menu-item <?php echo e(sideMenuActive('admin.role*', 3)); ?>">
                <a href="javascript:void(0);" class="menu-link menu-toggle">
                    <i class="menu-icon tf-icons las la-credit-card text-info"></i>
                    <div class="text-truncate"><?php echo app('translator')->get('Role'); ?></div>
                </a>
                <ul class="menu-sub">
                    <li class="menu-item <?php echo e(sideMenuActive('admin.role.index*', 1)); ?>">
                        <a href="<?php echo e(route('admin.role.index')); ?>" class="menu-link">
                            <div class="text-truncate"><?php echo app('translator')->get('Role List'); ?></div>
                        </a>
                    </li>

                    <li class="menu-item <?php echo e(sideMenuActive('admin.role.list*', 1)); ?>">
                        <a href="<?php echo e(route('admin.role.list')); ?>" class="menu-link">
                            <div class="text-truncate"><?php echo app('translator')->get('User Role'); ?></div>
                        </a>
                    </li>

                    <li class="menu-item <?php echo e(sideMenuActive('admin.role.permission.list*', 1)); ?>">
                        <a href="<?php echo e(route('admin.role.permission.list')); ?>" class="menu-link">
                            <div class="text-truncate"><?php echo app('translator')->get('Role & Permission'); ?></div>
                        </a>
                    </li>
                </ul>
            </li>
        <?php endif; ?>

        <?php if(Gate::forUser($admin)->check('has-permission', 'settings')): ?>
            <li class="menu-header small">
                <span class="menu-header-text"><?php echo app('translator')->get('GENERAL PREFERENCES'); ?></span>
            </li>

            <li class="menu-item <?php echo e(sideMenuActive('admin.basic*', 1)); ?>">
                <a href="<?php echo e(route('admin.basic.setting')); ?>" class="menu-link">
                    <i class="menu-icon tf-icons las la-cog text-purple"></i>
                    <div class="text-truncate"><?php echo app('translator')->get('Settings'); ?></div>
                </a>
            </li>
        <?php endif; ?>

        <?php if(Gate::forUser($admin)->check('has-permission', 'cache clear')): ?>
            <li class="menu-header small">
                <span class="menu-header-text"><?php echo app('translator')->get('OTHERS'); ?></span>
            </li>
            <li class="menu-item sidebar-menu-item">
                <a href="<?php echo e(route('admin.cache.clear')); ?>" class="menu-link">
                    <i class="menu-icon tf-icons las la-eraser text-indigo"></i>
                    <div class="text-truncate"><?php echo app('translator')->get('Cache Clear'); ?></div>
                </a>
            </li>
        <?php endif; ?>

    </ul>
</aside>
<?php /**PATH E:\NexERP\NexERP\well\nucleus\resources\views/admin/partials/sidebar.blade.php ENDPATH**/ ?>