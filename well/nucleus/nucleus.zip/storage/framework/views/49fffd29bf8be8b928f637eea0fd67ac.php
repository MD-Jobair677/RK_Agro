
<?php $__env->startSection('master'); ?>
    <div class="row">
        <div class="col-xxl">
            <div class="card">
                <div class="card-body table-responsive text-nowrap fixed-min-height-table">
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('has-permission', 'category create')): ?>
                        <button type="button" class="btn btn-sm btn-success detailBtn" data-bs-toggle="offcanvas"
                            data-bs-target="#offcanvasBoth" data-url="<?php echo e(route('admin.category.store')); ?>"
                            data-form-text-informations ='{"heading":"Create Category","button_name":"Create"}'
                            aria-controls="offcanvasBoth">
                            <span class="tf-icons las la-plus-circle me-1"></span>
                            <?php echo app('translator')->get('Add New'); ?>
                        </button>
                    <?php endif; ?>

                    <table class="table table-hover">
                        <thead>
                            <tr>
                                <th><?php echo app('translator')->get('SI'); ?></th>
                                <th class="text-center"><?php echo app('translator')->get('Name'); ?></th>
                                <th class="text-center"><?php echo app('translator')->get('Status'); ?></th>
                                <th class="text-center"><?php echo app('translator')->get('Created At'); ?></th>
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('has-permission', 'category edit')): ?>
                                    <th><?php echo app('translator')->get('Actions'); ?></th>
                                <?php endif; ?>
                            </tr>
                        </thead>
                        <tbody class="table-border-bottom-0">
                            <?php $__empty_1 = true; $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td><?php echo e($loop->iteration); ?></td>
                                    <td class="text-center"><?php echo e($category->name); ?></td>
                                    <td class="text-center"><?php echo $category->statusBadge ?></td>
                                    <td class="text-center"><?php echo e(showDateTime($category->created_at, 'd-m-y, h:i A')); ?></td>
                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('has-permission', 'category edit')): ?>
                                    <td>
                                        <button type="button" class="btn btn-sm btn-warning btn-label-info detailBtn"
                                            data-bs-toggle="offcanvas" data-bs-target="#offcanvasBoth"
                                            data-url="<?php echo e(route('admin.category.update', $category->id)); ?>"
                                            data-form-text-informations ='{"heading":"Update Category","button_name":"Update"}'
                                            data-category="<?php echo e($category); ?>" aria-controls="offcanvasBoth">
                                            <span class="tf-icons las la-pen me-1"></span> <?php echo app('translator')->get('Edit'); ?>
                                        </button>
                                    </td>
                                    <?php endif; ?>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="100%" class="text-center"><?php echo e(__($emptyMessage)); ?></td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>

                <?php if($categories->hasPages()): ?>
                    <div class="card-footer pagination justify-content-center">
                        <?php echo e(paginateLinks($categories)); ?>

                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <div class="offcanvas offcanvas-end" data-bs-scroll="true" tabindex="-1" id="offcanvasBoth"
        aria-labelledby="offcanvasBothLabel">
        <div class="offcanvas-header">
            <h4 id="offcanvasBothLabel" class="offcanvas-title"><?php echo app('translator')->get('Create Category'); ?></h4>
        </div>
        <div class="offcanvas-body my-auto mx-0">
            <div class="mb-4 border rounded p-3">

                <form id="offcanvasForm" class="card-body" action="#" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="row mb-3">
                                <label class="col-sm-3 col-form-label required"><?php echo app('translator')->get('Category Name'); ?></label>
                                <div class="col-sm-9">
                                    <input type="text" class="form-control" name="name"
                                        placeholder="<?php echo app('translator')->get('Enter your category name'); ?>" required>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-12">
                            <div class="row mb-3">
                                <label class="col-sm-3 col-form-label required"><?php echo app('translator')->get('Status'); ?></label>
                                <div class="col-sm-9">
                                    <select class="form-select" name="status" required>
                                        <option value="1"><?php echo app('translator')->get('Active'); ?></option>
                                        <option value="0"><?php echo app('translator')->get('Inactive'); ?></option>
                                    </select>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="row pt-4">
                        <div class="col-12 text-end">
                            <button type="submit" class="btn btn-primary me-sm-2 me-1 sds"><?php echo app('translator')->get('Create'); ?></button>
                            <button type="reset" class="btn btn-label-secondary"
                                data-bs-dismiss="offcanvas"><?php echo app('translator')->get('Cancel'); ?></button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('breadcrumb'); ?>
    <?php if (isset($component)) { $__componentOriginal544536d57896589479704f53a6577b7c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal544536d57896589479704f53a6577b7c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.searchForm','data' => ['placeholder' => 'Search Category...','dateSearch' => 'no']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('searchForm'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['placeholder' => 'Search Category...','dateSearch' => 'no']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal544536d57896589479704f53a6577b7c)): ?>
<?php $attributes = $__attributesOriginal544536d57896589479704f53a6577b7c; ?>
<?php unset($__attributesOriginal544536d57896589479704f53a6577b7c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal544536d57896589479704f53a6577b7c)): ?>
<?php $component = $__componentOriginal544536d57896589479704f53a6577b7c; ?>
<?php unset($__componentOriginal544536d57896589479704f53a6577b7c); ?>
<?php endif; ?>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('page-script'); ?>
    <script>
        document.querySelectorAll('.detailBtn').forEach(button => {
            button.addEventListener('click', function(event) {
                // find inside the offcanvas class and id
                const form = document.getElementById('offcanvasForm');
                const nameInput = document.getElementsByName('name')[0];
                const statusInput = document.getElementsByName('status')[0];
                const formHeading = document.getElementsByClassName('offcanvas-title')[0];
                const formButton = form.querySelector('button[type="submit"]');
                form.reset();

                // Example: Fetch and display data from the button attributes
                let url = this.getAttribute('data-url');
                let formTextInformations = JSON.parse(this.getAttribute('data-form-text-informations'));
                let category = JSON.parse(this.getAttribute('data-category'));

                // Optionally, set this information inside the offcanvas
                form.setAttribute('action', url);
                formHeading.textContent = formTextInformations.heading;
                formButton.textContent = formTextInformations.button_name;

                if (category) {
                    nameInput.value = category.name;
                    statusInput.value = category.status;
                }
            });
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\NexERP\NexERP\well\nucleus\resources\views/admin/common/cate_index.blade.php ENDPATH**/ ?>